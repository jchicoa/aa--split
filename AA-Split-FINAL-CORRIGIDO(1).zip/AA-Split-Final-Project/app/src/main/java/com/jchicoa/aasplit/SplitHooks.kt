package com.jchicoa.aasplit
import de.robv.android.xposed.XC_MethodReplacement
import de.robv.android.xposed.XposedHelpers
import io.github.libxposed.api.XposedModule
import io.github.libxposed.api.XposedModuleInterface.*

object SplitHooks {
    fun hookNewAPI(param: PackageLoadedParam, module: XposedModule) {
        val cl = param.classLoader
        val targets = listOf(
            "com.google.android.projection.gearhead.dashboard.DashboardSplitController" to "isSplitAvailable",
            "com.google.android.projection.gearhead.model.CarAppValidator" to "isValidForDashboard",
            "com.google.android.projection.gearhead.dashboard.DashboardSplitController" to "isAppAllowedForSplit",
            "com.google.android.projection.gearhead.model.CarAppValidator" to "isAppAllowedInSplit"
        )
        for ((className, methodName) in targets) {
            try {
                val clazz = cl.loadClass(className)
                // hook with String param
                try {
                    val m = clazz.getDeclaredMethod(methodName, String::class.java)
                    module.hook(m, Boolean::class.javaObjectType, object : XposedModule.Hooker {
                        override fun afterHookedMethod(cb: MethodHookParam) { cb.result = true }
                    })
                    continue
                } catch (_: Exception) {}
                // hook without param
                val m2 = clazz.getDeclaredMethod(methodName)
                module.hook(m2, Boolean::class.javaObjectType, object : XposedModule.Hooker {
                    override fun afterHookedMethod(cb: MethodHookParam) { cb.result = true }
                })
            } catch (_: Throwable) {}
        }
    }

    fun hookLegacyAPI(lp: de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam) {
        val hooks = listOf(
            Triple("com.google.android.projection.gearhead.dashboard.DashboardSplitController", "isSplitAvailable", null),
            Triple("com.google.android.projection.gearhead.dashboard.DashboardSplitController", "isAppAllowedForSplit", String::class.java),
            Triple("com.google.android.projection.gearhead.model.CarAppValidator", "isValidForDashboard", String::class.java),
            Triple("com.google.android.projection.gearhead.model.CarAppValidator", "isAppAllowedInSplit", String::class.java)
        )
        for ((cls, method, param) in hooks) {
            try {
                if (param == null) {
                    XposedHelpers.findAndHookMethod(cls, lp.classLoader, method, XC_MethodReplacement.returnConstant(true))
                } else {
                    XposedHelpers.findAndHookMethod(cls, lp.classLoader, method, param, XC_MethodReplacement.returnConstant(true))
                }
            } catch (_: Throwable) {}
        }
    }
}

package com.jchicoa.aasplit
import io.github.libxposed.api.XposedInterface
import io.github.libxposed.api.XposedModule
import io.github.libxposed.api.XposedModuleInterface.*

class MainHook(base: XposedInterface, param: ModuleLoadedParam) : XposedModule(base, param) {
    override fun onPackageLoaded(param: PackageLoadedParam): Boolean {
        if (param.packageName != "com.google.android.projection.gearhead") return false
        SplitHooks.hookNewAPI(param, this)
        return true
    }
}
class LegacyHook : de.robv.android.xposed.IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.google.android.projection.gearhead") return
        SplitHooks.hookLegacyAPI(lpparam)
    }
}

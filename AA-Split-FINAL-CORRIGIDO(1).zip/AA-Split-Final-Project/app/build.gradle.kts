plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.jchicoa.aasplit"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.jchicoa.aasplit"
        minSdk = 28
        targetSdk = 34
        versionCode = 2
        versionName = "2.0-final-api102"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildTypes { release { isMinifyEnabled = false } }
}
dependencies {
    compileOnly("org.lsposed.libxposed:libxposed-api:0.2.0")
    compileOnly("de.robv.android.xposed:api:82")
}

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://api.lsposed.org/")
        maven("https://api.xposed.info/")
    }
}
rootProject.name = "AA-Split-Unlock"
include(":app")
